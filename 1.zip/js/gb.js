function turnoff(obj) {
	document.getElementById(obj).style.display = "none";
}
